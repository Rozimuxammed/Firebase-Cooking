import React, { useEffect, useState } from 'react'
import { firestore } from '../firebase/config'
import { MdDelete } from "react-icons/md";


function Card() {
    const [cook, setCook] = useState([])
    useEffect(() => {
        firestore.collection("cooking").onSnapshot((data) => {
            var result = []
            if (!data.empty) {
                data.docs.forEach((item) => {
                    result.push(item.data());
                })
                setCook(result);
            }
        })
    }, [])
    return (
        <>
            {cook.map((item) => {
                return <div className='card'>
                    <MdDelete className='trash' />
                    <h1>{item.title}</h1>
                    <h3><b>Cooking Time : </b>{item.cookingTime} minutes</h3>
                    <h3><b>Resipe :</b> {item.ingredients.map((item) => {
                        return <span>{item} , </span>
                    })}</h3>
                    <h3><b>Method :</b> {item.method}</h3>
                    <button>MORE</button>
                </div>
            })}
        </>
    )
}

export default Card