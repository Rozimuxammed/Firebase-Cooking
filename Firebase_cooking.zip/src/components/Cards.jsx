import React from 'react'
import Card from './Card'

function Cards() {
    return (
        <div className=' cards container'>
            <Card />
        </div>
    )
}

export default Cards