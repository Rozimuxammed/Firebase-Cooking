import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function Create() {
    const [title, setTitle] = useState("")
    const [time, setTime] = useState()
    const [ingridient, setIngridient] = useState("")
    const [ingridients, setIngridients] = useState([])

    const navigate = useNavigate()

    const handleSubmit = (e) => {
        e.preventDefault()
        const obj = {
            title,
            method: metod,
            cookingTime: time,
            ingredients: ingridients,
        }
        console.log(obj);
    }


    return (
        <div className="form">
            <div className="container">
                <h1>Create</h1>
                <form onSubmit={handleSubmit}>
                    <input onChange={(e) => {
                        setTitle(e.target.value)
                    }} type="text" placeholder='Name' />
                    <div className="Add">
                        <input type="text" placeholder='Ingrediend' />
                        <button onClick={() => {
                            setIngridients([...ingridients, ingridient])
                        }} type='button'>Add</button>
                    </div>
                    <div className="resipe">
                        Ingredined :  {ingridients.map((item) => {

                        })}
                    </div>
                    <textarea onChange={((e) => {
                        setMetod(e.target.value)
                    })} placeholder='Info'></textarea>
                    <input onChange={((e) => {
                        setTime(e.target.value)
                    })} placeholder='Time' type="number" />
                    <button>Add</button>
                </form>
            </div>
        </div>
    )
}

export default Create