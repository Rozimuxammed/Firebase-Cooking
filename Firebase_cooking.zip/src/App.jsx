import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Cards from './components/Cards'
import Navbar from './components/Navbar'
import Create from './components/Create'
import { useState } from 'react'



function App() {
  const [mode, setMode] = useState(false)
  return (
    <div className={mode ? "app light" : "app"}>
      <BrowserRouter>
        <Navbar mode={mode} setMode={setMode} />
        <Routes>
          <Route path='/' element={<Cards />} />
          <Route path='/create' element={<Create />} />
        </Routes>

      </BrowserRouter>
    </div>
  )
}

export default App
